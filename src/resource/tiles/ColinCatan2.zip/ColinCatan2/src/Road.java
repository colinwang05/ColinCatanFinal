




public class Road extends Infrastructure{
    private Pair tiles, connection;
    public Road(){
        super();
    }
    public Road(Pair tiles, Pair connection){

    }

    public Pair getTiles(){
        return tiles;
    }

    public Pair getConnection(){
        return connection;
    }

}
