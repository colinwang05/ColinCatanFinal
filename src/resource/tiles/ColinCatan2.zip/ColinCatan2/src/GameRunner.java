/*
 * 1
 */

public class GameRunner {
    public static void main(String[] args) {
        GUIWindow guiWindow = new GUIWindow("GUI Window parameter to be decided");
        //GameBoard game = new GameBoard(ParentPanel.numberOfPlayers, ParentPanel.initialWaterLevel, ParentPanel.seed);


    }


}
