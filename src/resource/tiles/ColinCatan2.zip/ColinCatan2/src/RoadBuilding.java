
public class RoadBuilding extends DevelopmentCard{
    public RoadBuilding(){
        super("road building");
    }
    public void use(int p, int ti, int loc1, int t2, int loc2){

    }
}
